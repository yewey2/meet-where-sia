import { useEffect, useMemo, useState } from 'react';
import { ParticipantCard } from './components/ParticipantCard';
import { MapPanel } from './components/MapPanel';
import { ResultPanel } from './components/ResultPanel';
import {
  MapPinIcon,
  PlusIcon,
  RailIcon,
  RouteIcon,
  SparkIcon,
  UsersIcon,
} from './components/Icons';
import { createId } from './lib/ids';
import {
  distanceMetrics,
  geometricMedian,
  rankStations,
} from './lib/centroid';
import {
  emptyLocation,
  hasCoordinates,
} from './lib/location';
import {
  geocodeLocation,
  getGoogleMapsApiKey,
  loadGoogleMaps,
  reverseGeocode,
} from './lib/googleMaps';
import { fetchMrtStations, fetchTrainAlerts } from './lib/api';
import type {
  EndpointPoint,
  LocationValue,
  MeetingResult,
  Mode,
  MrtStation,
  Participant,
  TrainAlertPayload,
} from './types';

const STORAGE_KEY = 'meetmiddle-sg-v1';

function createParticipant(name = ''): Participant {
  return {
    id: createId('person'),
    name,
    sameAsStart: false,
    start: emptyLocation(),
    end: emptyLocation(),
  };
}

function isLocationValue(value: unknown): value is LocationValue {
  if (!value || typeof value !== 'object') return false;
  const candidate = value as Partial<LocationValue>;
  return typeof candidate.query === 'string' && typeof candidate.status === 'string';
}

function loadSavedState(): { participants: Participant[]; mode: Mode } {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return { participants: [createParticipant()], mode: 'distance' };
    const parsed = JSON.parse(raw) as {
      participants?: Participant[];
      mode?: Mode;
    };

    const participants = Array.isArray(parsed.participants)
      ? parsed.participants.filter(
          (participant) =>
            participant &&
            typeof participant.id === 'string' &&
            typeof participant.name === 'string' &&
            typeof participant.sameAsStart === 'boolean' &&
            isLocationValue(participant.start) &&
            isLocationValue(participant.end),
        )
      : [];

    return {
      participants: participants.length ? participants : [createParticipant()],
      mode: parsed.mode === 'rail' ? 'rail' : 'distance',
    };
  } catch {
    return { participants: [createParticipant()], mode: 'distance' };
  }
}

function buildEndpointPoints(participants: Participant[]): EndpointPoint[] {
  return participants.flatMap((participant, index) => {
    const participantName = participant.name.trim() || `Person ${index + 1}`;
    const points: EndpointPoint[] = [];

    if (hasCoordinates(participant.start)) {
      points.push({
        id: `${participant.id}-start`,
        participantId: participant.id,
        participantName,
        kind: 'start',
        label: participant.start.label || participant.start.query,
        lat: participant.start.lat,
        lng: participant.start.lng,
      });
    }

    const end = participant.sameAsStart ? participant.start : participant.end;
    if (hasCoordinates(end)) {
      points.push({
        id: `${participant.id}-end`,
        participantId: participant.id,
        participantName,
        kind: 'end',
        label: end.label || end.query,
        lat: end.lat,
        lng: end.lng,
      });
    }

    return points;
  });
}

class FieldResolutionError extends Error {
  participantId: string;
  field: 'start' | 'end';

  constructor(
    participantId: string,
    field: 'start' | 'end',
    message: string,
  ) {
    super(message);
    this.participantId = participantId;
    this.field = field;
  }
}

async function resolveField(
  participant: Participant,
  field: 'start' | 'end',
  displayName: string,
): Promise<LocationValue> {
  const location = participant[field];

  if (!location.query.trim()) {
    throw new FieldResolutionError(
      participant.id,
      field,
      `${displayName} needs an ${field === 'start' ? 'starting' : 'ending'} point.`,
    );
  }

  if (hasCoordinates(location) && location.status === 'resolved') {
    return location;
  }

  try {
    return await geocodeLocation(location);
  } catch (error) {
    throw new FieldResolutionError(
      participant.id,
      field,
      `${displayName} ${field}: ${
        error instanceof Error ? error.message : 'location could not be resolved.'
      }`,
    );
  }
}

export default function App() {
  const saved = useMemo(loadSavedState, []);
  const [participants, setParticipants] = useState<Participant[]>(saved.participants);
  const [mode, setMode] = useState<Mode>(saved.mode);
  const [result, setResult] = useState<MeetingResult | null>(null);
  const [stations, setStations] = useState<MrtStation[]>([]);
  const [stationLoadError, setStationLoadError] = useState('');
  const [trainAlerts, setTrainAlerts] = useState<TrainAlertPayload | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [globalError, setGlobalError] = useState('');
  const hasGoogleKey = Boolean(getGoogleMapsApiKey());
  const mapPoints = useMemo(() => buildEndpointPoints(participants), [participants]);

  useEffect(() => {
    try {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify({ participants, mode }),
      );
    } catch {
      // The planner still works when storage is blocked (for example, private embeds).
    }
  }, [mode, participants]);

  useEffect(() => {
    if (!hasGoogleKey) return;
    void loadGoogleMaps().catch(() => {
      // The map and individual fields show a more specific setup error.
    });
  }, [hasGoogleKey]);

  useEffect(() => {
    const controller = new AbortController();
    void fetchTrainAlerts(controller.signal)
      .then(setTrainAlerts)
      .catch(() => {
        setTrainAlerts({
          configured: false,
          available: false,
          status: 'unavailable',
          affectedSegments: [],
          messages: [],
        });
      });
    return () => controller.abort();
  }, []);

  useEffect(() => {
    if (mode !== 'rail' || stations.length > 0 || stationLoadError) return;
    const controller = new AbortController();

    void fetchMrtStations(controller.signal)
      .then((response) => {
        setStations(response.stations);
        setStationLoadError('');
      })
      .catch((error) => {
        if (error instanceof DOMException && error.name === 'AbortError') return;
        setStationLoadError(
          error instanceof Error
            ? error.message
            : 'The official rail station list could not be loaded.',
        );
      });

    return () => controller.abort();
  }, [mode, stationLoadError, stations.length]);

  function updateParticipant(next: Participant) {
    setParticipants((current) =>
      current.map((participant) =>
        participant.id === next.id ? next : participant,
      ),
    );
    setResult(null);
    setGlobalError('');
  }

  function addParticipant() {
    setParticipants((current) => [
      ...current,
      createParticipant(`Person ${current.length + 1}`),
    ]);
    setResult(null);
  }

  function loadExample() {
    setParticipants([
      {
        id: createId('person'),
        name: 'John Doe',
        sameAsStart: true,
        start: emptyLocation('Senja LRT'),
        end: emptyLocation('Senja LRT'),
      },
      {
        id: createId('person'),
        name: 'Aisha Tan',
        sameAsStart: false,
        start: emptyLocation('ION Orchard'),
        end: emptyLocation('425-500'),
      },
    ]);
    setMode('distance');
    setResult(null);
    setGlobalError('');
  }

  function resetPlanner() {
    setParticipants([createParticipant()]);
    setMode('distance');
    setResult(null);
    setGlobalError('');
  }

  async function ensureStations(): Promise<MrtStation[]> {
    if (stations.length) return stations;
    const response = await fetchMrtStations();
    setStations(response.stations);
    setStationLoadError('');
    return response.stations;
  }

  async function calculateMeetingPoint() {
    setGlobalError('');
    setIsCalculating(true);
    setResult(null);

    if (!hasGoogleKey) {
      setGlobalError(
        'Add VITE_GOOGLE_MAPS_API_KEY to .env before resolving locations.',
      );
      setIsCalculating(false);
      return;
    }

    setParticipants((current) =>
      current.map((participant) => ({
        ...participant,
        start:
          participant.start.query && participant.start.status !== 'resolved'
            ? { ...participant.start, status: 'resolving' }
            : participant.start,
        end:
          !participant.sameAsStart &&
          participant.end.query &&
          participant.end.status !== 'resolved'
            ? { ...participant.end, status: 'resolving' }
            : participant.sameAsStart
              ? { ...participant.start }
              : participant.end,
      })),
    );

    try {
      const resolvedParticipants: Participant[] = [];

      for (let index = 0; index < participants.length; index += 1) {
        const participant = participants[index];
        const displayName = participant.name.trim() || `Person ${index + 1}`;
        const start = await resolveField(participant, 'start', displayName);
        const end = participant.sameAsStart
          ? { ...start }
          : await resolveField(participant, 'end', displayName);

        resolvedParticipants.push({ ...participant, start, end });
      }

      const points = buildEndpointPoints(resolvedParticipants);
      if (points.length === 0) {
        throw new Error('Add at least one valid start and end point.');
      }

      setParticipants(resolvedParticipants);

      if (mode === 'distance') {
        const center = geometricMedian(points);
        const metrics = distanceMetrics(center, points);
        const address = await reverseGeocode(center);
        const title = address.split(',')[0]?.trim() || 'Fair distance center';

        setResult({
          mode: 'distance',
          ...center,
          ...metrics,
          title,
          address,
        });
      } else {
        const availableStations = await ensureStations();
        const ranked = rankStations(availableStations, points);
        const selected = ranked[0];

        if (!selected) {
          throw new Error('No MRT/LRT stations were available for comparison.');
        }

        const address = await reverseGeocode(selected);
        setResult({
          mode: 'rail',
          lat: selected.lat,
          lng: selected.lng,
          title: `${selected.name} ${selected.network}`,
          address,
          station: selected,
          alternatives: ranked.slice(0, 4),
          totalKm: selected.totalKm,
          averageKm: selected.averageKm,
          maxKm: selected.maxKm,
        });

        void fetchTrainAlerts().then(setTrainAlerts).catch(() => undefined);
      }
    } catch (error) {
      if (error instanceof FieldResolutionError) {
        setParticipants((current) =>
          current.map((participant) => {
            if (participant.id !== error.participantId) return participant;
            return {
              ...participant,
              [error.field]: {
                ...participant[error.field],
                status: 'error',
              },
            };
          }),
        );
      }

      setGlobalError(
        error instanceof Error
          ? error.message
          : 'The meeting point could not be calculated.',
      );
    } finally {
      setIsCalculating(false);
    }
  }

  const modeDescription =
    mode === 'distance'
      ? 'Minimizes the combined straight-line kilometres across every start and end point.'
      : 'Compares every official Singapore MRT/LRT station and picks the lowest total distance.';

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><MapPinIcon /></div>
          <div>
            <strong>MeetMiddle</strong>
            <span>Singapore</span>
          </div>
          <span className="version-badge">V1</span>
        </div>

        <div className="api-statuses">
          <span className={`api-pill ${hasGoogleKey ? 'is-ready' : 'needs-setup'}`}>
            <i /> Google {hasGoogleKey ? 'ready' : 'key needed'}
          </span>
          <span
            className={`api-pill ${
              trainAlerts?.configured ? 'is-ready' : 'is-optional'
            }`}
          >
            <i /> LTA {trainAlerts?.configured ? 'connected' : 'optional'}
          </span>
        </div>
      </header>

      <main className="planner-layout">
        <section className="planner-panel">
          <div className="planner-intro">
            <div className="eyebrow"><SparkIcon /> Group meeting planner</div>
            <h1>Find the fairest place to meet.</h1>
            <p>
              Enter every person’s start and end point. The app resolves each
              Singapore location, then finds one practical center for the group.
            </p>
          </div>

          {!hasGoogleKey ? (
            <div className="setup-banner">
              <strong>Google Maps key required</strong>
              <span>
                Copy <code>.env.example</code> to <code>.env</code> and add your
                browser key to enable autocomplete, geocoding, and the map.
              </span>
            </div>
          ) : null}

          <div className="mode-section">
            <div className="section-label">How should the center be chosen?</div>
            <div className="mode-switch" role="radiogroup" aria-label="Meeting point mode">
              <button
                type="button"
                role="radio"
                aria-checked={mode === 'distance'}
                className={mode === 'distance' ? 'is-selected' : ''}
                onClick={() => {
                  setMode('distance');
                  setResult(null);
                  setGlobalError('');
                }}
              >
                <RouteIcon />
                <span><strong>Pure distance</strong><small>Default · geometric median</small></span>
              </button>
              <button
                type="button"
                role="radio"
                aria-checked={mode === 'rail'}
                className={mode === 'rail' ? 'is-selected' : ''}
                onClick={() => {
                  setMode('rail');
                  setResult(null);
                  setGlobalError('');
                }}
              >
                <RailIcon />
                <span><strong>Nearest MRT/LRT</strong><small>Official station comparison</small></span>
              </button>
            </div>
            <p className="mode-description">{modeDescription}</p>
            {mode === 'rail' && stationLoadError ? (
              <p className="inline-warning">Station data: {stationLoadError}</p>
            ) : null}
          </div>

          <div className="people-section">
            <div className="people-header">
              <div>
                <div className="section-label"><UsersIcon /> People and routes</div>
                <p>{participants.length} {participants.length === 1 ? 'person' : 'people'} in this plan</p>
              </div>
              <button type="button" className="text-button" onClick={loadExample}>
                Load example
              </button>
            </div>

            <div className="participant-list">
              {participants.map((participant, index) => (
                <ParticipantCard
                  key={participant.id}
                  participant={participant}
                  index={index}
                  canRemove={participants.length > 1}
                  onChange={updateParticipant}
                  onRemove={() => {
                    setParticipants((current) =>
                      current.filter((item) => item.id !== participant.id),
                    );
                    setResult(null);
                    setGlobalError('');
                  }}
                />
              ))}
            </div>

            <button type="button" className="add-person-button" onClick={addParticipant}>
              <PlusIcon /> Add another person
            </button>
          </div>

          {globalError ? (
            <div className="global-error" role="alert">
              <strong>Check the route details</strong>
              <span>{globalError}</span>
            </div>
          ) : null}

          <button
            type="button"
            className="calculate-button"
            disabled={isCalculating}
            onClick={() => void calculateMeetingPoint()}
          >
            {isCalculating ? <span className="button-spinner" /> : <SparkIcon />}
            {isCalculating
              ? 'Calculating…'
              : mode === 'distance'
                ? 'Find the distance center'
                : 'Find the best MRT/LRT'}
          </button>

          <div className="planner-footnote">
            <span>V1 saves the plan only in this browser.</span>
            <button type="button" onClick={resetPlanner}>Clear plan</button>
          </div>
          <p className="v2-note">
            Shared editable links, contributor emails, and multi-user changes are
            intentionally reserved for V2.
          </p>
        </section>

        <aside className="results-column">
          <MapPanel points={mapPoints} result={result} />
          <ResultPanel
            result={result}
            isCalculating={isCalculating}
            participantCount={participants.length}
            trainAlerts={trainAlerts}
            stationCount={stations.length}
          />
        </aside>
      </main>
    </div>
  );
}
